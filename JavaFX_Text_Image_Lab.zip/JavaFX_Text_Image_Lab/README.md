# JavaFX Text and Image Display Lab

## AIM
Create a JavaFX window titled **Text and Image Display** with a `Hello, JavaFX!` label and an image inside a vertical `VBox` layout. The scene is 600 × 400 pixels.

## Files
- `DisplayTextAndImage.java` — JavaFX source code.
- `images/imagePath.jpg` — Place your image file here. The folder includes a placeholder note.

## Important: Add an image
Copy any JPG image into the `images` folder and name it exactly:
`imagePath.jpg`

## Run
JavaFX must be installed and configured in your Java IDE or command line.

Example command (replace `/path/to/javafx-sdk/lib` with your JavaFX SDK `lib` folder):

```bash
javac --module-path /path/to/javafx-sdk/lib --add-modules javafx.controls DisplayTextAndImage.java
java --module-path /path/to/javafx-sdk/lib --add-modules javafx.controls DisplayTextAndImage
```

Run the commands from the project folder so `images/imagePath.jpg` can be found.

## Note
The JavaFX SDK is separate from many standard JDK installations. The application needs a real image file at the path above.
